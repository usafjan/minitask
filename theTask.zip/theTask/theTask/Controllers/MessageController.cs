﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using theTask.Models;

namespace theTask.Controllers
{
    public class MessageController : Controller
    {
        // 1. *************RETRIEVE ALL MESSAGE DETAILS ******************
        // GET: MESSAGE
        
        public ActionResult Index()
        {
            MessageDBHandle dbhandle = new MessageDBHandle();
            ModelState.Clear();

             return View(dbhandle.GetMessages());
            
        }

        // 2. *************ADD NEW MESSAGE ******************
        // GET: MESSAGE/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: MESSAGE/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(MessageModel smodel, HttpPostedFileBase UserFile)
        {
            try
            {

                MessageDBHandle sdb = new MessageDBHandle();

                //GET MESSAGE COUNT 
                int lst = sdb.GetMessageCount(smodel);

                //CHECK IF MESSAGE ALREADY IN DB 
                if (lst < 1)
                {

                    /////////upload file
                    //CHECK IF FILE NOT EMPTY
                    if (UserFile != null && UserFile.ContentLength > 0)
                    {
                        ///CHECK FILE EXTENSION
                        if (UserFile.FileName.EndsWith(".csv") || UserFile.FileName.EndsWith(".xls") || UserFile.FileName.EndsWith(".xlsx"))
                        {
                            var fileName = System.IO.Path.GetFileName(UserFile.FileName);
                            ///SET FILE NAME TO USER FILE TO SAVE IN DB
                            smodel.UserFile = fileName;
                            ///SAVE FILE
                            var path = System.IO.Path.Combine(Server.MapPath("/App_Data"), fileName);
                            UserFile.SaveAs(path);
                        }
                        else
                        {
                            ModelState.AddModelError("UserFile", "This file format is not supported");
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("UserFile", "Please Upload Your file");
                    }

                    if (ModelState.IsValid)
                    {
                        ////SAVE MODEL
                        if (sdb.AddMessage(smodel))
                        {
                            ViewBag.Message = "Your  Message  { " + smodel.Message + " } Save Successfully!";
                            ModelState.Clear();
                        }

                    }
                }
                else
                {
                   
                    ViewBag.Message = "Record already inserted .!";
                    
                }
                return View();
            }
            catch
            {
               
                return View();
            }
        }

    }
}