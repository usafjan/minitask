﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace theTask.Models
{
    public class MessageDBHandle
    {
        private SqlConnection con;
        private void connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["MessageConn"].ToString();
            con = new SqlConnection(constring);
        }

        // **************** ADD New Message  *********************
        public bool AddMessage(MessageModel smodel)
        {
            connection();
            SqlCommand cmd = new SqlCommand("AddMessages", con);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@Message", smodel.Message);
            cmd.Parameters.AddWithValue("@SendDate", smodel.SendDate);
            cmd.Parameters.AddWithValue("@SendTime", smodel.SendTime);
            cmd.Parameters.AddWithValue("@UserFile", smodel.UserFile);

            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();

            if (i >= 1)
                return true;
            else
                return false;
        }

        // ********** VIEW MESSAGES  DETAILS ********************
        public List<MessageModel> GetMessages()
        {
            connection();
            List<MessageModel> msglist = new List<MessageModel>();

            SqlCommand cmd = new SqlCommand("GetMessages", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter sd = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();

            con.Open();
            sd.Fill(dt);
            con.Close();

            foreach (DataRow dr in dt.Rows)
            {
                msglist.Add(
                    new MessageModel
                    {
                        Id = Convert.ToInt32(dr["Id"]),
                        Message = Convert.ToString(dr["Message"]),
                        SendDate = Convert.ToString(dr["SendDate"]),
                        SendTime = Convert.ToString(dr["SendTime"]),
                        UserFile = Convert.ToString(dr["UserFile"])
                    });
            }
            return msglist;
        }

        // ********** GET MESSAGE COUNT  ********************
        public int GetMessageCount(MessageModel smodel)
        {
            connection();

           //GET SYSTEM DATE
            string date = DateTime.Now.ToShortDateString();
            //SqlCommand cmd = new SqlCommand("select count(*) from dbo.Messages where Message=@Message and SendDate=@SendDate" , con);
            SqlCommand cmd = new SqlCommand("MessageCount", con);
            cmd.CommandType = CommandType.StoredProcedure;
            con.Open();
            

             cmd.Parameters.AddWithValue("@Message", smodel.Message);
             cmd.Parameters.AddWithValue("@SendDate", date);

            int count = Convert.ToInt32(cmd.ExecuteScalar());
            //Console.WriteLine("count is {0}", count);
            con.Close();
            return count;
        }

    }
}