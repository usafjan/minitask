﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace theTask.Models
{
    public class MessageModel
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(160, ErrorMessage = "Max 160 characters allowed")]
        [MinLength(20, ErrorMessage = "Min 20 characters allowed")]
        [Display(Name = "Message")]
        [RegularExpression(@"([a-z]|[A-Z]|[0-9]|[ ]|[-]|[_])*$", ErrorMessage = "special characters are not allowed.")]
        public string Message { get; set; }

        [Required]
        public string UserFile { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public string SendDate { get; set; }

        [Required]
        [DataType(DataType.Time)]
        public string SendTime { get; set; }

       
    }
}